<?php
/**
 * AG FLORIST Journal page.
 * To use: publish an empty WordPress page with slug "journal".
 * Product items are excluded from the editorial listing.
 */
get_header();
$ag_exclude = array();
$ag_product_root = get_term_by('slug','item','category');
if ($ag_product_root instanceof WP_Term) {
  $ag_exclude[] = (int)$ag_product_root->term_id;
  $ag_children = get_term_children($ag_product_root->term_id, 'category');
  if (!is_wp_error($ag_children)) {
    $ag_exclude = array_merge($ag_exclude, array_map('intval', $ag_children));
  }
}
$ag_args = array('post_type'=>'post','post_status'=>'publish', 'posts_per_page'=>9, 'paged'=>max(1,(int)get_query_var('paged')));
if ($ag_exclude) { $ag_args['category__not_in'] = $ag_exclude; }
$ag_journal = new WP_Query($ag_args);
?>
<main class="ag-journal" id="main-content">
  <section class="ag-editorial-hero">
    <p class="ag-editorial-hero__en">JOURNAL</p>
    <h1>読みもの</h1>
    <p>美容の仕事と、毎日の暮らしに寄り添うトピックス。</p>
  </section>
  <div class="ag-journal__inner">
    <?php if ($ag_journal->have_posts()) : ?>
      <div class="ag-journal__grid">
      <?php while ($ag_journal->have_posts()) : $ag_journal->the_post(); ?>
        <article <?php post_class('ag-journal__card'); ?>>
          <a href="<?php the_permalink(); ?>">
            <?php if (has_post_thumbnail()) : ?><div class="ag-journal__thumb"><?php the_post_thumbnail('medium_large',array('loading'=>'lazy')); ?></div><?php else : ?><div class="ag-journal__thumb ag-journal__thumb--placeholder"><span>AG FLORIST</span></div><?php endif; ?>
            <div class="ag-journal__text"><time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date('Y.m.d')); ?></time><h2><?php the_title(); ?></h2><span>記事を読む ›</span></div>
          </a>
        </article>
      <?php endwhile; ?>
      </div>
      <nav class="ag-journal__pages" aria-label="記事一覧のページ移動">
      <?php echo wp_kses_post(paginate_links(array('total'=>$ag_journal->max_num_pages,'current'=>max(1,(int)get_query_var('paged'))))); ?>
      </nav>
    <?php else : ?>
      <p class="ag-journal__empty">現在公開中の記事はありません。</p>
    <?php endif; wp_reset_postdata(); ?>
  </div>
</main>
<?php get_footer(); ?>
